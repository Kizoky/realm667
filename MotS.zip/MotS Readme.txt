Information:
Source: Mysteries of the Sith
Count: ~5300
Palette: PNG
Format: Patches/Flats
Description: Textures from Mysteries of the Sith

Credits:
Conversion: Clonehunter
Author: LucasArts
Submitted: Clonehunter

Description: 
All Textures from Mysteries of the Sith, including Playermodel textures just because someone might find a use for them (And because they were the .GOO file along with the nomral textures).
I'm not sure, but I believe this mioght also contain all of the Textures from Dark Forces II as well, as I noticed a large number of them, and MotS does reuse a number of textures.  
I'm not completely certain.